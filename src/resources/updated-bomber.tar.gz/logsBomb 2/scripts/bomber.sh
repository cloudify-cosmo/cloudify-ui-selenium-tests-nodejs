#! /bin/bash

for a in {1..20}
do
  ctx logger debug "DEBUG: You have been BOMBED"
  ctx logger info "INFO: You have been BOMBED"
  ctx logger warning "WARNING: You have been BOMBED"
  ctx logger error "ERROR: You have been BOMBED"
  ctx logger critical "CRITICAL: You have been BOMBED"
done  
