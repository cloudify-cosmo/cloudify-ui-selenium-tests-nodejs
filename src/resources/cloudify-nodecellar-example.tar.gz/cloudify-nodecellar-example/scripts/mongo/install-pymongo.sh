#!/bin/bash

ctx logger info "Installing pymongo"

pip install pymongo